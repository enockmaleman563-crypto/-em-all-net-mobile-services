import { useState, useEffect } from 'react'
import './App.css'

const today = () => {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
}

const fields = [
  'Airtel Money','Mixx by Yas','M-Pesa','HaloPesa',
  'NMB','CRDB','LIPA NAMBA','Cash (Taslimu)','Madeni'
]

const emptyAccounts = () => Object.fromEntries(fields.map(f => [f, '']))

function App() {
  const [credentials, setCredentials] = useState(() =>
    JSON.parse(localStorage.getItem('emall_credentials') ||
    '{"username":"admin","password":"1234"}')
  )

  const [loggedIn, setLoggedIn] = useState(
    localStorage.getItem('emall_login') === 'true'
  )
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [oldPassword, setOldPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')

  const [tab, setTab] = useState('entry')
  const [date, setDate] = useState(today())
  const [accounts, setAccounts] = useState(emptyAccounts())
  const [sales, setSales] = useState([])

  const [history, setHistory] = useState(() =>
    JSON.parse(localStorage.getItem('emall_history') || '{}')
  )
  const [logs, setLogs] = useState(() =>
    JSON.parse(localStorage.getItem('emall_logs') || '[]')
  )

  const money = n => Number(n || 0).toLocaleString('en-US')

  const agentTotal = fields.reduce(
    (sum, f) => sum + Number(accounts[f] || 0), 0
  )

  const salesTotal = sales.reduce(
    (sum, s) => sum + Number(s.qty || 0) * Number(s.price || 0), 0
  )

  const profit = sales.reduce(
    (sum, s) => sum + Number(s.qty || 0) *
    (Number(s.price || 0) - Number(s.cost || 0)), 0
  )

  useEffect(() => {
    const saved = history[date]
    setAccounts(saved?.accounts || emptyAccounts())
    setSales(saved?.sales || [])
  }, [date])

  function login(e) {
    e.preventDefault()

    if (
      username === credentials.username &&
      password === credentials.password
    ) {
      setLoggedIn(true)
      localStorage.setItem('emall_login', 'true')
      setUsername('')
      setPassword('')
    } else {
      alert('Username au Password si sahihi!')
    }
  }

  function logout() {
    setLoggedIn(false)
    localStorage.removeItem('emall_login')
    setTab('entry')
  }

  function changePassword(e) {
    e.preventDefault()

    if (oldPassword !== credentials.password) {
      alert('Password ya zamani si sahihi!')
      return
    }

    if (newPassword.length < 4) {
      alert('Password mpya iwe na angalau herufi/namba 4!')
      return
    }

    if (newPassword !== confirmPassword) {
      alert('Password mpya hazifanani!')
      return
    }

    const updated = {
      ...credentials,
      password: newPassword
    }

    setCredentials(updated)
    localStorage.setItem('emall_credentials', JSON.stringify(updated))

    setOldPassword('')
    setNewPassword('')
    setConfirmPassword('')

    alert('Password imebadilishwa vizuri!')
    setTab('entry')
  }

  function save() {
    const updated = {
      ...history,
      [date]: { date, accounts, sales }
    }

    setHistory(updated)
    localStorage.setItem('emall_history', JSON.stringify(updated))

    const newLogs = [
      {
        date,
        time: new Date().toLocaleTimeString(),
        message: 'Hesabu zimehifadhiwa'
      },
      ...logs
    ]

    setLogs(newLogs)
    localStorage.setItem('emall_logs', JSON.stringify(newLogs))

    alert('Hesabu zimehifadhiwa vizuri!')
  }

  function addPhone() {
    setSales([
      ...sales,
      { id: Date.now(), model: '', qty: 1, cost: '', price: '' }
    ])
  }

  function updatePhone(id, key, value) {
    setSales(sales.map(s =>
      s.id === id ? { ...s, [key]: value } : s
    ))
  }

  if (!loggedIn) {
    return (
      <main className="app login-page">
        <section className="login-card">
          <img className="brand-logo login-logo" src="/em-logo.png" alt="EM logo" />
          <h2>EM ALL NET</h2>
          <h3>MOBILE SERVICES</h3>
          <p>AGENT & MOBILE SALES MANAGER</p>

          <form onSubmit={login}>
            <label>USERNAME</label>
            <input
              value={username}
              onChange={e => setUsername(e.target.value)}
              placeholder="Ingiza username"
              required
            />

            <label>PASSWORD</label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Ingiza password"
              required
            />

            <button className="save" type="submit">
              INGIA KWENYE MFUMO
            </button>
          </form>

          <footer>EM ALL NET MOBILE SERVICES</footer>
        </section>
      </main>
    )
  }

  return (
    <main className="app">
      <header className="top">
        <div className="brand-heading"><img className="brand-logo header-logo" src="/em-logo.png" alt="EM logo" /><div><h2>EM ALL NET MOBILE SERVICES</h2>
        <p>AGENT & MOBILE SALES MANAGER</p></div></div>
        <button className="logout" onClick={logout}>LOGOUT</button>
      </header>

      <nav className="navigation">
        <button className={tab === 'entry' ? 'active' : ''}
          onClick={() => setTab('entry')}>Ingiza Hesabu</button>

        <button className={tab === 'history' ? 'active' : ''}
          onClick={() => setTab('history')}>History</button>

        <button className={tab === 'logs' ? 'active' : ''}
          onClick={() => setTab('logs')}>Log za Huduma</button>

        <button className={tab === 'password' ? 'active' : ''}
          onClick={() => setTab('password')}>Badili Password</button>
      </nav>

      {tab === 'entry' && <>
        <section className="panel">
          <h3>HESABU ZA KILA SIKU</h3>
          <label>Tarehe</label>
          <input
            type="date"
            value={date}
            onChange={e => setDate(e.target.value)}
          />
        </section>

        <section className="panel">
          <h3>HESABU ZA WAKALA</h3>

          {fields.map(field => (
            <div className="field" key={field}>
              <label>{field}</label>
              <input
                type="number"
                min="0"
                placeholder="Ingiza kiasi"
                value={accounts[field]}
                onChange={e =>
                  setAccounts({ ...accounts, [field]: e.target.value })
                }
              />
            </div>
          ))}

          <div className="total">
            <span>JUMLA YA WAKALA</span>
            <strong>TSh {money(agentTotal)}</strong>
          </div>
        </section>

        <section className="panel">
          <h3>MAUZO YA SIMU</h3>
          <p>Tarehe ya mauzo: <strong>{date}</strong></p>
          <p className="note">
            Hesabu za simu ni tofauti na za wakala.
          </p>

          {sales.map((phone, index) => (
            <div className="phone-card" key={phone.id}>
              <h4>SIMU {index + 1}</h4>

              <label>Aina / Model ya simu</label>
              <input
                placeholder="Mfano: Samsung A15"
                value={phone.model}
                onChange={e => updatePhone(phone.id, 'model', e.target.value)}
              />

              <label>Idadi</label>
              <input
                type="number"
                min="1"
                value={phone.qty}
                onChange={e => updatePhone(phone.id, 'qty', e.target.value)}
              />

              <label>Bei ya kununua (moja)</label>
              <input
                type="number"
                placeholder="TSh"
                value={phone.cost}
                onChange={e => updatePhone(phone.id, 'cost', e.target.value)}
              />

              <label>Bei ya kuuza (moja)</label>
              <input
                type="number"
                placeholder="TSh"
                value={phone.price}
                onChange={e => updatePhone(phone.id, 'price', e.target.value)}
              />

              <p>Jumla ya mauzo:
                <strong> TSh {money(Number(phone.qty) * Number(phone.price))}</strong>
              </p>

              <p>Faida:
                <strong> TSh {money(Number(phone.qty) *
                  (Number(phone.price) - Number(phone.cost)))}</strong>
              </p>

              <button className="delete"
                onClick={() => setSales(sales.filter(s => s.id !== phone.id))}>
                Futa simu
              </button>
            </div>
          ))}

          <button className="add" onClick={addPhone}>
            + ONGEZA SIMU NYINGINE
          </button>

          <div className="total">
            <span>JUMLA YA MAUZO YA SIMU</span>
            <strong>TSh {money(salesTotal)}</strong>
          </div>

          <div className="total profit">
            <span>FAIDA YA SIMU</span>
            <strong>TSh {money(profit)}</strong>
          </div>
        </section>

        <button className="save" onClick={save}>
          HIFADHI HESABU
        </button>
      </>}

      {tab === 'history' && (
        <section className="panel">
          <h3>HISTORY YA HESABU</h3>

          {Object.keys(history).length === 0 &&
            <p>Bado hakuna hesabu zilizohifadhiwa.</p>}

          {Object.keys(history).sort().reverse().map(day => {
            const record = history[day]
            const total = fields.reduce(
              (sum, f) => sum + Number(record.accounts[f] || 0), 0
            )
            const phoneTotal = record.sales.reduce(
              (sum, s) => sum + Number(s.qty || 0) *
              Number(s.price || 0), 0
            )

            return (
              <div className="history-card" key={day}>
                <h4>{day}</h4>
                <p>Jumla ya wakala:
                  <strong> TSh {money(total)}</strong>
                </p>
                <p>Mauzo ya simu:
                  <strong> TSh {money(phoneTotal)}</strong>
                </p>
                <button className="add"
                  onClick={() => {
                    setDate(day)
                    setTab('entry')
                  }}>
                  Fungua hesabu
                </button>
              </div>
            )
          })}
        </section>
      )}

      {tab === 'logs' && (
        <section className="panel">
          <h3>LOG ZA HUDUMA</h3>

          {logs.length === 0 && <p>Hakuna kumbukumbu bado.</p>}

          {logs.map((log, i) => (
            <div className="history-card" key={i}>
              <p><strong>{log.date}</strong> - {log.time}</p>
              <p>{log.message}</p>
            </div>
          ))}
        </section>
      )}

      {tab === 'password' && (
        <section className="panel">
          <h3>BADILI PASSWORD</h3>

          <form onSubmit={changePassword}>
            <label>Password ya zamani</label>
            <input
              type="password"
              value={oldPassword}
              onChange={e => setOldPassword(e.target.value)}
              placeholder="Password ya zamani"
              required
            />

            <label>Password mpya</label>
            <input
              type="password"
              value={newPassword}
              onChange={e => setNewPassword(e.target.value)}
              placeholder="Password mpya"
              required
            />

            <label>Rudia password mpya</label>
            <input
              type="password"
              value={confirmPassword}
              onChange={e => setConfirmPassword(e.target.value)}
              placeholder="Thibitisha password mpya"
              required
            />

            <button className="save" type="submit">
              HIFADHI PASSWORD MPYA
            </button>
          </form>
        </section>
      )}

      <footer>
        EM ALL NET MOBILE SERVICES © {new Date().getFullYear()}
      </footer>
    </main>
  )
}

export default App
