package com.emallnet.mobile.services;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
